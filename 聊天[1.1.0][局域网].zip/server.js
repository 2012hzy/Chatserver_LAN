// ===== 局域网聊天器服务端 (无依赖版，含留言系统) =====
const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");
const readline = require("readline");
const os = require("os");

// 创建 HTTP 服务器 (提供 client.html 和静态资源)
const server = http.createServer((req, res) => {
  let filePath = path.join(__dirname, req.url === "/" ? "client.html" : req.url);
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("404 Not Found");
    } else {
      let ext = path.extname(filePath).toLowerCase();
      let type = {
        ".html": "text/html",
        ".js": "text/javascript",
        ".css": "text/css",
        ".json": "application/json",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".gif": "image/gif"
      }[ext] || "text/plain";
      res.writeHead(200, { "Content-Type": type + "; charset=utf-8" });
      res.end(data);
    }
  });
});

const wss = new WebSocket.Server({ server });

const clients = {};   // { username: ws }
const userIPs = {};   // { username: ip }
const bannedIPs = new Set();
const historyFile = path.join(__dirname, "history.json");
let history = [];

// ========== IP 格式化 ==========
function cleanIP(ip) {
  if (ip === "::1") return "127.0.0.1";
  if (ip.startsWith("::ffff:")) return ip.substring(7);
  return ip;
}

// 读取历史记录
if (fs.existsSync(historyFile)) {
  try { history = JSON.parse(fs.readFileSync(historyFile)); }
  catch { history = []; }
}

function broadcast(msg, except = null) {
  Object.values(clients).forEach(c => {
    if (c !== except && c.readyState === WebSocket.OPEN) {
      c.send(JSON.stringify(msg));
    }
  });
}

function broadcastSystem(text) {
  broadcast({ type: "system", text });
  console.log("[系统]", text);
}

function updateUserList() {
  broadcast({ type: "userlist", users: Object.keys(clients) });
}

function saveHistory() {
  fs.writeFileSync(historyFile, JSON.stringify(history.slice(-500), null, 2));
}

// ===== 管理员命令 =====
function execAdminCommand(cmd, args) {
  switch (cmd) {
    case "/help":
      return `
===== 管理员命令 =====
/help                 查看命令说明
/list                 查看当前在线用户
/kick <用户名>        踢出用户
/ban <用户名>         封禁用户
/unban <IP>           解封 IP
======================`;
    case "/list":
      return "在线用户：" + (Object.keys(clients).join(", ") || "无");
    case "/kick":
      {
        let user = args[0];
        if (clients[user]) {
          clients[user].send(JSON.stringify({ type: "system", text: "你已被管理员踢出" }));
          clients[user].close();
          return `[管理员] 踢出用户: ${user}`;
        }
        return "用户不存在";
      }
    case "/ban":
      {
        let user = args[0];
        if (clients[user]) {
          let ip = userIPs[user];
          bannedIPs.add(ip);
          clients[user].send(JSON.stringify({ type: "system", text: "你已被管理员封禁" }));
          clients[user].close();
          return `[管理员] 封禁用户: ${user} (IP: ${ip})`;
        }
        return "用户不存在";
      }
    case "/unban":
      {
        let ip = args[0];
        if (bannedIPs.has(ip)) {
          bannedIPs.delete(ip);
          return `[管理员] 解封 IP: ${ip}`;
        }
        return "该 IP 不在封禁列表中";
      }
    default:
      return "未知命令, 输入 /help 查看帮助";
  }
}

// ===== WebSocket 事件 =====
wss.on("connection", (ws, req) => {
  let ip = cleanIP(req.socket.remoteAddress);
  let port = req.socket.remotePort;
  let username = null;

  if (bannedIPs.has(ip)) {
    ws.send(JSON.stringify({ type: "system", text: "你已被封禁" }));
    ws.close();
    return;
  }

  console.log(`[连接] ${ip}:${port}`);
  ws.send(JSON.stringify({ type: "history", messages: history }));

  ws.on("message", (data) => {
    let msg;
    try { msg = JSON.parse(data.toString()); }
    catch { msg = data.toString().trim(); }

    // ===== 文件消息 =====
    if (typeof msg === "object" && msg.type === "file") {
      if (!username) return;
      let record = {
        type: "file",
        from: username,
        fileName: msg.fileName,
        fileData: msg.fileData,
        time: msg.time || getTime()
      };
      history.push(record);
      saveHistory();
      broadcast(record);
      return;
    }

    // ===== 留言消息 =====
    if (typeof msg === "object" && msg.type === "comment") {
      if (!username) return;
      let record = {
        type: "comment",
        from: username,
        targetTime: msg.targetTime,
        targetUser: msg.targetUser,
        text: msg.text,
        time: getTime()
      };
      history.push(record);
      saveHistory();
      broadcast(record);

      let notice = `${username}[${record.time}] 评论了你的言论`;
      if (clients[record.targetUser]) {
        clients[record.targetUser].send(JSON.stringify({ type: "system", text: notice }));
      }
      return;
    }

    // ===== 文本消息 =====
    if (typeof msg === "string") {
      if (msg.startsWith("/register ")) {
        let name = msg.split(" ")[1];
        if (!name) return;
        if (userIPs[name] || clients[name]) {
          ws.send(JSON.stringify({ type: "system", text: "用户名已存在" }));
          return;
        }
        username = name;
        clients[username] = ws;
        userIPs[username] = ip;
        ws.send(JSON.stringify({ type: "system", text: "注册成功，已登录" }));
        broadcastSystem(`${username} 注册 (${ip}:${port})`);
        updateUserList();
        return;
      }

      if (msg.startsWith("/login ")) {
        let name = msg.split(" ")[1];
        if (!name) return;
        if (clients[name]) {
          ws.send(JSON.stringify({ type: "system", text: "该用户已在线" }));
          return;
        }
        if (userIPs[name] && userIPs[name] !== ip) {
          ws.send(JSON.stringify({ type: "system", text: "登录失败：IP 不匹配" }));
          return;
        }
        username = name;
        clients[username] = ws;
        userIPs[username] = ip;
        ws.send(JSON.stringify({ type: "system", text: "登录成功" }));
        broadcastSystem(`${username} 登录 (${ip}:${port})`);
        updateUserList();
        return;
      }

      if (username) {
        let record = { type: "chat", from: username, text: msg, time: getTime() };
        history.push(record);
        saveHistory();
        broadcast(record);
      }
    }
  });

  ws.on("close", () => {
    if (username) {
      delete clients[username];
      broadcastSystem(`${username} 断开 (${ip}:${port})`);
      updateUserList();
    } else {
      console.log(`[断开] ${ip}:${port}`);
    }
  });
});

// ===== 服务端命令行 =====
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
console.log(execAdminCommand("/help", []));
rl.on("line", (line) => {
  let args = line.trim().split(" ");
  let cmd = args.shift();
  let result = execAdminCommand(cmd, args);
  console.log(result);
});

function getTime() {
  let d = new Date();
  return d.getHours().toString().padStart(2,"0")+":"+
         d.getMinutes().toString().padStart(2,"0");
}

// 启动 HTTP + WS
server.listen(3000, "0.0.0.0", () => {
  const nets = os.networkInterfaces();
  const results = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === "IPv4" && !net.internal) {
        results.push(net.address);
      }
    }
  }
  console.log("服务器已启动，可在以下地址访问：");
  results.forEach(ip => {
    console.log(`  http://${ip}:3000`);
  });
});
