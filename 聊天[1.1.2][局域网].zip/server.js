// ===== 局域网聊天器服务端 (含密码系统和消息ID支持) =====
const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");
const readline = require("readline");
const os = require("os");
const crypto = require("crypto");

// 创建 HTTP 服务器
const server = http.createServer((req, res) => {
  let filePath = path.join(__dirname, req.url === "/" ? "client.html" : req.url);
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("404 Not Found");
    } else {
      let ext = path.extname(filePath).toLowerCase();
      let type = {
        ".html": "text/html",
        ".js": "text/javascript",
        ".css": "text/css",
        ".json": "application/json",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".gif": "image/gif"
      }[ext] || "text/plain";
      res.writeHead(200, { "Content-Type": type + "; charset=utf-8" });
      res.end(data);
    }
  });
});

const wss = new WebSocket.Server({ server });

const clients = {};   // { username: ws }
const userIPs = {};   // { username: ip }
const userPasswords = {}; // { username: hashedPassword }
const ipRegistrations = {}; // { ip: username } 记录每个IP注册的用户
const bannedIPs = new Set();
const historyFile = path.join(__dirname, "history.json");
const usersFile = path.join(__dirname, "users.json");
let history = [];
let users = {};

// ========== IP 格式化 ==========
function cleanIP(ip) {
  if (ip === "::1") return "127.0.0.1";
  if (ip.startsWith("::ffff:")) return ip.substring(7);
  return ip;
}

// 读取历史记录和用户数据
if (fs.existsSync(historyFile)) {
  try { 
    history = JSON.parse(fs.readFileSync(historyFile)); 
    // 为历史消息添加ID（如果不存在）
    history.forEach(msg => {
      if (!msg.id) {
        msg.id = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      }
    });
  }
  catch(e) { 
    console.log("读取历史记录错误:", e);
    history = []; 
  }
}

if (fs.existsSync(usersFile)) {
  try { 
    users = JSON.parse(fs.readFileSync(usersFile)); 
    console.log("已加载用户数据:", Object.keys(users).length, "个用户");
  }
  catch(e) { 
    console.log("读取用户数据错误:", e);
    users = {}; 
  }
}

// 密码哈希函数
function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

function broadcast(msg, except = null) {
  Object.values(clients).forEach(c => {
    if (c !== except && c.readyState === WebSocket.OPEN) {
      c.send(JSON.stringify(msg));
    }
  });
}

function broadcastSystem(text) {
  broadcast({ type: "system", text });
  console.log("[系统]", text);
}

function updateUserList() {
  broadcast({ type: "userlist", users: Object.keys(clients) });
}

function saveHistory() {
  try {
    // 只保存最近500条消息
    const recentHistory = history.slice(-500);
    fs.writeFileSync(historyFile, JSON.stringify(recentHistory, null, 2));
    console.log("历史记录已保存到文件");
  } catch (error) {
    console.error("保存历史记录错误:", error);
  }
}

function saveUsers() {
  try {
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    console.log("用户数据已保存到 users.json:", Object.keys(users).length, "个用户");
  } catch (error) {
    console.error("保存用户数据错误:", error);
  }
}

// 生成唯一消息ID
function generateMessageId() {
  return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// ===== 管理员命令 =====
function execAdminCommand(cmd, args) {
  switch (cmd) {
    case "/help":
      return `
===== 管理员命令 =====
/help                 查看命令说明
/list                 查看当前在线用户
/kick <用户名>        踢出用户
/ban <用户名>         封禁用户
/unban <IP>           解封 IP
/passwd <用户> <新密码> 重置用户密码
/clearip <IP>         清除IP注册记录
/rename <旧用户名> <新用户名> 重命名用户
======================`;
    case "/list":
      return "在线用户：" + (Object.keys(clients).join(", ") || "无");
    case "/kick":
      {
        let user = args[0];
        if (clients[user]) {
          clients[user].send(JSON.stringify({ type: "system", text: "你已被管理员踢出" }));
          clients[user].close();
          return `[管理员] 踢出用户: ${user}`;
        }
        return "用户不存在";
      }
    case "/ban":
      {
        let user = args[0];
        if (clients[user]) {
          let ip = userIPs[user];
          bannedIPs.add(ip);
          clients[user].send(JSON.stringify({ type: "system", text: "你已被管理员封禁" }));
          clients[user].close();
          return `[管理员] 封禁用户: ${user} (IP: ${ip})`;
        }
        return "用户不存在";
      }
    case "/unban":
      {
        let ip = args[0];
        if (bannedIPs.has(ip)) {
          bannedIPs.delete(ip);
          return `[管理员] 解封 IP: ${ip}`;
        }
        return "该 IP 不在封禁列表中";
      }
    case "/passwd":
      {
        let user = args[0];
        let newPassword = args[1];
        if (users[user]) {
          users[user] = hashPassword(newPassword);
          saveUsers();
          return `[管理员] 已重置用户 ${user} 的密码`;
        }
        return "用户不存在";
      }
    case "/clearip":
      {
        let ip = args[0];
        if (ipRegistrations[ip]) {
          delete ipRegistrations[ip];
          return `[管理员] 已清除IP ${ip} 的注册记录`;
        }
        return "该 IP 没有注册记录";
      }
    case "/rename":
      {
        let oldUsername = args[0];
        let newUsername = args[1];
        
        if (!users[oldUsername]) {
          return "用户不存在";
        }
        
        if (users[newUsername]) {
          return "新用户名已存在";
        }
        
        // 更新用户数据
        users[newUsername] = users[oldUsername];
        delete users[oldUsername];
        
        // 更新IP注册记录
        for (let ipKey in ipRegistrations) {
          if (ipRegistrations[ipKey] === oldUsername) {
            ipRegistrations[ipKey] = newUsername;
          }
        }
        
        // 更新在线用户
        if (clients[oldUsername]) {
          clients[newUsername] = clients[oldUsername];
          delete clients[oldUsername];
          
          userIPs[newUsername] = userIPs[oldUsername];
          delete userIPs[oldUsername];
        }
        
        // 更新历史记录中的用户名
        history.forEach(msg => {
          if (msg.from === oldUsername) {
            msg.from = newUsername;
          }
          if (msg.type === "comment" && msg.targetUser === oldUsername) {
            msg.targetUser = newUsername;
          }
        });
        
        saveUsers();
        saveHistory();
        updateUserList();
        
        return `[管理员] 已将用户 ${oldUsername} 重命名为 ${newUsername}`;
      }
    default:
      return "未知命令, 输入 /help 查看帮助";
  }
}

// ===== WebSocket 事件 =====
wss.on("connection", (ws, req) => {
  let ip = cleanIP(req.socket.remoteAddress);
  let port = req.socket.remotePort;
  let username = null;

  if (bannedIPs.has(ip)) {
    ws.send(JSON.stringify({ type: "system", text: "你已被封禁" }));
    ws.close();
    return;
  }

  console.log(`[连接] ${ip}:${port}`);
  // 发送历史消息给新连接的用户
  ws.send(JSON.stringify({ type: "history", messages: history }));

  ws.on("message", (data) => {
    let msg;
    try { 
      msg = JSON.parse(data.toString());
      
      // 处理纯数字消息
      if (typeof msg === "number") {
        msg = msg.toString();
      }
    } catch(e) { 
      msg = data.toString().trim();
    }

    // ===== 文件消息 =====
    if (typeof msg === "object" && msg.type === "file") {
      if (!username) return;
      let record = {
        type: "file",
        from: username,
        fileName: msg.fileName,
        fileData: msg.fileData,
        time: msg.time || getTime(),
        id: generateMessageId() // 添加唯一ID
      };
      history.push(record);
      saveHistory();
      broadcast(record, ws); // 不发送给自己，因为客户端已经显示
      return;
    }

    // ===== 留言消息 =====
    if (typeof msg === "object" && msg.type === "comment") {
      if (!username) return;
      let record = {
        type: "comment",
        from: username,
        targetUser: msg.targetUser,
        targetId: msg.targetId, // 使用消息ID而不是时间戳
        text: msg.text,
        time: getTime()
      };
      history.push(record);
      saveHistory();
      broadcast(record);

      let notice = `${username}[${record.time}] 评论了你的消息`;
      if (clients[record.targetUser]) {
        clients[record.targetUser].send(JSON.stringify({ type: "system", text: notice }));
      }
      return;
    }

    // ===== 认证和消息 =====
    if (typeof msg === "object" && msg.type === "auth") {
      if (msg.action === "register") {
        let name = msg.username;
        let password = msg.password;
        
        if (!name || !password) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "用户名和密码不能为空" }));
          return;
        }
        
        // 检查IP是否已注册过用户
        if (ipRegistrations[ip]) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "该IP已注册过用户，不能重复注册" }));
          return;
        }
        
        if (users[name]) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "用户名已存在" }));
          return;
        }
        
        // 注册新用户
        users[name] = hashPassword(password);
        ipRegistrations[ip] = name; // 记录IP注册的用户
        saveUsers();
        
        username = name;
        clients[username] = ws;
        userIPs[username] = ip;
        ws.send(JSON.stringify({ type: "auth", status: "success", message: "注册成功", username: name }));
        broadcastSystem(`${username} 注册 (${ip}:${port})`);
        updateUserList();
        return;
      }
      
      if (msg.action === "login") {
        let name = msg.username;
        let password = msg.password;
        
        if (!name || !password) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "用户名和密码不能为空" }));
          return;
        }
        
        if (clients[name]) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "该用户已在线" }));
          return;
        }
        
        if (!users[name]) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "用户不存在" }));
          return;
        }
        
        if (users[name] !== hashPassword(password)) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "密码错误" }));
          return;
        }
        
        username = name;
        clients[username] = ws;
        userIPs[username] = ip;
        ws.send(JSON.stringify({ type: "auth", status: "success", message: "登录成功", username: name }));
        broadcastSystem(`${username} 登录 (${ip}:${port})`);
        updateUserList();
        return;
      }
      
      if (msg.action === "update_username") {
        let oldName = msg.oldUsername;
        let newName = msg.newUsername;
        
        if (!username || username !== oldName) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "未登录或用户名不匹配" }));
          return;
        }
        
        if (users[newName]) {
          ws.send(JSON.stringify({ type: "auth", status: "error", message: "新用户名已存在" }));
          return;
        }
        
        // 更新用户数据
        users[newName] = users[oldName];
        delete users[oldName];
        
        // 更新IP注册记录
        for (let ipKey in ipRegistrations) {
          if (ipRegistrations[ipKey] === oldName) {
            ipRegistrations[ipKey] = newName;
          }
        }
        
        // 更新在线用户
        clients[newName] = clients[oldName];
        delete clients[oldName];
        
        userIPs[newName] = userIPs[oldName];
        delete userIPs[oldName];
        
        // 更新历史记录中的用户名
        history.forEach(msg => {
          if (msg.from === oldName) {
            msg.from = newName;
          }
          if (msg.type === "comment" && msg.targetUser === oldName) {
            msg.targetUser = newName;
          }
        });
        
        username = newName;
        saveUsers();
        saveHistory();
        updateUserList();
        
        ws.send(JSON.stringify({ 
          type: "auth", 
          status: "success", 
          message: "用户名更新成功", 
          username: newName 
        }));
        
        broadcastSystem(`${oldName} 改名为 ${newName}`);
        return;
      }
    }

    // ===== 文本消息 =====
    if (typeof msg === "string") {
      // 处理纯数字消息
      if (!isNaN(msg) && msg.trim() !== "") {
        // 纯数字消息，直接发送
        if (username) {
          let record = { 
            type: "chat", 
            from: username, 
            text: msg, 
            time: getTime(),
            id: generateMessageId() // 添加唯一ID
          };
          history.push(record);
          saveHistory();
          broadcast(record, ws); // 不发送给自己，因为客户端已经显示
        }
        return;
      }
      
      if (msg.startsWith("/register ")) {
        // 旧版注册命令，已弃用
        ws.send(JSON.stringify({ type: "system", text: "请使用新的认证系统进行注册" }));
        return;
      }

      if (msg.startsWith("/login ")) {
        // 旧版登录命令，已弃用
        ws.send(JSON.stringify({ type: "system", text: "请使用新的认证系统进行登录" }));
        return;
      }

      if (username) {
        let record = { 
          type: "chat", 
          from: username, 
          text: msg, 
          time: getTime(),
          id: generateMessageId() // 添加唯一ID
        };
        history.push(record);
        saveHistory();
        broadcast(record, ws); // 不发送给自己，因为客户端已经显示
      }
    }
  });

  ws.on("close", () => {
    if (username) {
      delete clients[username];
      broadcastSystem(`${username} 断开 (${ip}:${port})`);
      updateUserList();
    } else {
      console.log(`[断开] ${ip}:${port}`);
    }
  });
});

// ===== 服务端命令行 =====
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
console.log(execAdminCommand("/help", []));
rl.on("line", (line) => {
  let args = line.trim().split(" ");
  let cmd = args.shift();
  let result = execAdminCommand(cmd, args);
  console.log(result);
});

function getTime() {
  let d = new Date();
  return d.getHours().toString().padStart(2,"0")+":"+
         d.getMinutes().toString().padStart(2,"0");
}

// 启动 HTTP + WS
server.listen(3000, "0.0.0.0", () => {
  const nets = os.networkInterfaces();
  const results = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === "IPv4" && !net.internal) {
        results.push(net.address);
      }
    }
  }
  console.log("服务器已启动，可在以下地址访问：");
  results.forEach(ip => {
    console.log(`  http://${ip}:3000`);
  });
});